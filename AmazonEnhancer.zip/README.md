# AmazonEnhancer 0.3
Webextension for improving your Amazon experience!

# FEATURES
- Dark/Night mode
- Clean up Amazon

# PLANNED
- More themes
- Improved item descriptions
- Remove fake/suspicious reviews (fakespot/regex)
- Detect suspicious items (high unverfied to verified review ratio)
- Support more domains
- Goodreads rating with books
- Applied referall link
- Improved icons
- Live settings implication
